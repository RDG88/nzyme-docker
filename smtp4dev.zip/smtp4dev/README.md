# Why SMTP4Dev
Since Nzyme does not have any other possibility to send alerting to email (other then directly fiddle with the postgress db - shell script)
The idea is as follow:

Nzyme sends an Alert to SMTP4Dev (just a dummy SMTP server).

SMTP4Dev has API's availble so we can read out the mailbox and send the alerts to a log aggragtion system.

# Setting up Nyme with Email integration
System -> Intergrations -> SMTP/Email
- Transport Strategy - SMTP
- Hostname	smtp4dev.smtp4dev.svc.cluster.local
- Port	25
- Username	Configure Anything, does not matter
- Password Configure anything, does not matter
- From Address	Configure anything, does not matter
- URL of nzyme Web Interface Configure anything, does not matter.

From here you can use the native alerting method from Nzyme.

## Test
Open a shell in a pod on the same cluster where smtp4dev is running and send e-mail via curl:
```
curl --url 'smtp://smtp4dev.smtp4dev.svc.cluster.local:25' \
  --mail-from 'from-email@gmail.com' \
  --mail-rcpt 'to-email@gmail.com' \
  --user 'from-email@gmail.com:YourPassword' \
  -T <(echo -e 'From: from-email@gmail.com\nTo: to-email@gmail.com\nSubject: Curl Test\n\nHello')
```

When you open the web interface (port forward the service) you can see the message coming in.

# SMTP4Dev web interface
SMTP4Dev has an web interface where you can check the recieved emails at port 80

# Todo
Create a script that polls the SMTP4Dev, and send a message to a log aggrigation system.