import os
import time
import requests
import logging
import logging_loki
import json

# Read environment variables, with default values if not set
base_url = os.getenv("BASE_URL", "http://smtp4dev.smtp4dev.svc.cluster.local:80/api")
loki_url = os.getenv("LOKI_URL", "http://loki.grafana-loki.svc.cluster.local:3100/loki/api/v1/push")
interval = int(os.getenv("INTERVAL", 60))  # Convert interval to integer
delete_on_read = os.getenv("DELETE_ON_READ", "true").lower() == "true"  # Convert to boolean

# Configure the console logger to ensure logs are output to stdout
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(console_formatter)

# Configure the Loki logging handler
loki_handler = logging_loki.LokiHandler(
    url=loki_url,
    tags={"application": "smtp4dev-email-logger"},
    version="1",
)

# Set up the logger for email content
logger = logging.getLogger("email-logger")
logger.setLevel(logging.INFO)
logger.addHandler(console_handler)
logger.addHandler(loki_handler)

# Set up a separate logger for message counting that only logs to the console
count_logger = logging.getLogger("count-logger")
count_logger.setLevel(logging.INFO)
count_logger.addHandler(console_handler)

# Set up another logger for detailed console-only logs
console_only_logger = logging.getLogger("console-only-logger")
console_only_logger.setLevel(logging.INFO)
console_only_logger.addHandler(console_handler)

def get_messages():
    # Get summaries of all messages
    response = requests.get(f"{base_url}/Messages")
    response.raise_for_status()
    messages = response.json()
    return messages['results']

def get_message_details(message_id):
    # Get the full details of a message by its ID
    response = requests.get(f"{base_url}/Messages/{message_id}")
    response.raise_for_status()
    message_details = response.json()
    return message_details

def delete_message(message_id):
    # Delete the message by its ID
    response = requests.delete(f"{base_url}/Messages/{message_id}")
    response.raise_for_status()
    console_only_logger.info(f"Deleted message ID: {message_id}")

def log_message_to_loki(message_details, plain_text_body):
    # Create a log entry as a JSON object
    log_entry = {
        "message_id": message_details['id'],
        "from": message_details.get('from', 'unknown'),
        "to": ', '.join(message_details.get('to', [])),
        "subject": message_details.get('subject', 'no-subject'),
        "received_date": message_details['receivedDate'],
        "plain_text_body": plain_text_body
    }
    # Log the entry as a JSON string
    logger.info(json.dumps(log_entry), extra={"tags": {"message_id": message_details['id']}})

def print_and_log_message_content(message_details):
    # Print the plain text or HTML body of the message
    message_id = message_details['id']
    
    # Try to get the plain text body
    response = requests.get(f"{base_url}/Messages/{message_id}/plaintext")
    if response.status_code == 200 and response.text:
        console_only_logger.info("Plain Text Body:")
        console_only_logger.info(response.text)
        # Log the plain text body to Loki
        try:
            log_message_to_loki(message_details, response.text)
            return True  # Return True if logging is successful
        except Exception as e:
            logger.error(f"Failed to log to Loki: {e}")
            return False  # Return False if logging fails
    else:
        console_only_logger.info("No plain text body found.")
        return False

def main():
    while True:
        try:
            # Get all messages
            messages = get_messages()
            
            # Only log the number of messages if there are more than 0
            if len(messages) > 0:
                count_logger.info(f"Found {len(messages)} messages.")
            
                for message in messages:
                    console_only_logger.info(f"\nNew email received:")
                    console_only_logger.info(f"Message ID: {message['id']}")
                    console_only_logger.info(f"From: {message.get('from')}")
                    console_only_logger.info(f"To: {', '.join(message.get('to', []))}")
                    console_only_logger.info(f"Subject: {message['subject']}")
                    console_only_logger.info(f"Received Date: {message['receivedDate']}")
                    
                    # Get full message details
                    message_details = get_message_details(message['id'])
                    
                    # Print and log message content
                    success = print_and_log_message_content(message_details)
                    
                    # Delete the message if logging is successful and DELETE_ON_READ is True
                    if success and delete_on_read:
                        delete_message(message['id'])

        except Exception as e:
            logger.error(f"Error occurred: {e}")

        # Wait for the specified interval before checking again
        time.sleep(interval)

if __name__ == "__main__":
    main()